jQuery(function () {
	let rawToken = "";

	// Hàm che token: giữ lại 3 ký tự đầu và 2 ký tự cuối, còn lại thay thế bằng dấu *
	function maskToken(token) {
		if (!token || token.length < 5) return "*****";
		const start = token.slice(0, 3);
		const end = token.slice(-2);
		const middle = "*".repeat(token.length - 5);
		return start + middle + end;
	}

	// Kiểm tra trang và lấy token tự động
	function checkAndGetToken() {
		chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
			if (!tabs.length || !tabs[0].url) {
				jQuery('#status-text').html("❌ Không thể xác định trang hiện tại.");
				jQuery('#status-container').show();
				jQuery('#token-container').hide();
				return;
			}

			const isDiscord = tabs[0].url.includes("discord.com");
			if (!isDiscord) {
				jQuery('#status-text').html("❌ Vui lòng truy cập trang web <a class='notice-link' href='https://discord.com/channels/@me' target='_blank'>discord.com</a> để lấy token.");
				jQuery('#status-container').show();
				jQuery('#token-container').hide();
				return;
			}

			// Gửi tin nhắn đến content script trên trang Discord
			chrome.tabs.sendMessage(tabs[0].id, { action: "openExtensionPopup" }, function(token) {
				if (chrome.runtime.lastError) {
					// Lỗi kết nối (tiện ích chưa tải lại trang)
					jQuery('#status-text').html("⚠️ Vui lòng <b>F5 (tải lại)</b> trang Discord để tiện ích hoạt động!");
					jQuery('#status-container').show();
					jQuery('#token-container').hide();
					return;
				}

				if (token) {
					rawToken = token;
					jQuery('#token').val(maskToken(token));
					jQuery('#status-container').hide();
					jQuery('#token-container').show();
				} else {
					// Đã F5 nhưng chưa đăng nhập hoặc không thấy token cookie
					jQuery('#status-text').html("❌ Bạn chưa đăng nhập Discord. Vui lòng đăng nhập tài khoản của bạn!");
					jQuery('#status-container').show();
					jQuery('#token-container').hide();
				}
			});
		});
	}

	// Thực hiện tự động kiểm tra ngay khi mở sidepanel
	checkAndGetToken();

	// Tự động quét theo chu kỳ (polling 1s) để tự detect token khi vừa F5 hoặc chuyển trang
	const pollInterval = setInterval(checkAndGetToken, 1000);

	// Lắng nghe sự kiện chuyển tab hoặc tải lại tab trong Chrome
	if (chrome.tabs) {
		chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
			if (changeInfo.status === 'complete' || changeInfo.url) {
				checkAndGetToken();
			}
		});

		chrome.tabs.onActivated.addListener(() => {
			checkAndGetToken();
		});
	}

	// Sự kiện click nút Sao chép
	jQuery('.copy-btn').click(function () {
		if (!rawToken) return;

		chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
			if (tabs.length && tabs[0].url && tabs[0].url.includes("discord.com")) {
				// Lưu token gốc vào clipboard
				navigator.clipboard.writeText(rawToken).then(function () {
					// Đổi trạng thái nút sao chép tạm thời thành công
					const btn = jQuery('.copy-btn');
					const originalText = btn.html();
					
					btn.html("✓ Đã sao chép!");
					btn.addClass('success');
					
					setTimeout(() => {
						btn.html(originalText);
						btn.removeClass('success');
					}, 2000);

					// Gửi thông báo toast hiển thị trên trang Discord
					chrome.tabs.sendMessage(tabs[0].id, { 
						action: "showToast", 
						message: "🔑 Đã sao chép Discord Token thành công vào bộ nhớ tạm!" 
					});
				}).catch(function (err) {
					alert('Lỗi sao chép: ' + err);
				});
			} else {
				alert("Tiện ích này chỉ hoạt động trên trang web discord.com!");
			}
		});
	});

	// Đường dẫn mở trang cài đặt
	jQuery('.openOptions').click(function (e) {
		e.preventDefault();
		chrome.runtime.openOptionsPage();
	});
});
