var s = document.createElement('script');
s.src = chrome.runtime.getURL('js/web-script.js');
s.onload = function () {
	this.remove();
};
(document.head || document.documentElement).appendChild(s);

// Thêm style cho toast thông báo trực tiếp trên Discord
const style = document.createElement('style');
style.textContent = `
  .txa-toast {
    position: fixed;
    top: 30px;
    right: 30px;
    background: rgba(47, 49, 54, 0.95);
    color: #ffffff;
    padding: 15px 25px;
    border-radius: 8px;
    border-left: 5px solid #43b581;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
    font-family: 'Whitney', 'Helvetica Neue', Helvetica, Arial, sans-serif;
    font-size: 14px;
    font-weight: 600;
    z-index: 999999;
    opacity: 0;
    transform: translateY(-20px);
    transition: all 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    backdrop-filter: blur(8px);
    display: flex;
    align-items: center;
    pointer-events: none;
  }
  .txa-toast.show {
    opacity: 1;
    transform: translateY(0);
  }
`;
document.head.appendChild(style);

// Function to retrieve a cookie by name
function getCookie(name) {
	const cookies = document.cookie.split(';');
	for (var i = 0; i < cookies.length; i++) {
		const cookie = cookies[i].trim();
		const [cookieName, cookieValue] = cookie.split('=');
		if (cookieName === name) {
			return cookieValue;
		}
	}
	return null;
}

// Listen for messages from the popup/sidepanel
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	if (message.action === "openExtensionPopup") {
		sendResponse(getCookie("discordUserToken"));
	} else if (message.action === "showToast") {
		// Tạo và hiển thị Toast trên trang Discord
		const toast = document.createElement('div');
		toast.className = 'txa-toast';
		toast.innerHTML = `<span>${message.message}</span>`;
		document.body.appendChild(toast);
		
		// Kích hoạt animation hiện ra
		setTimeout(() => toast.classList.add('show'), 50);
		
		// Ẩn và xóa Toast sau 3 giây
		setTimeout(() => {
			toast.classList.remove('show');
			setTimeout(() => toast.remove(), 300);
		}, 3000);
	}
});